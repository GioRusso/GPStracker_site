package com.raptrx.gpstracker;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class MainActivity extends AppCompatActivity implements LocationListener {

    private static final int MY_PERMISSION_REQUEST = 1;
    private LocationManager nLocationManager;
    private String TAG = "LocalizacionApp";
    private TextView tvLat,tvLon,datetime;
    private String LONG="", LATI="";
    public String MSG = "TESTING MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLat = (TextView) findViewById(R.id.tvLat);
        tvLon = (TextView) findViewById(R.id.tvLon);
        datetime = (TextView) findViewById(R.id.datetime);

        nLocationManager = (LocationManager) this.getSystemService(
                Context.LOCATION_SERVICE);

    }

    public void onClickStart(View view) {
        if (       ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG,"Faltan permisos");
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                            }, MY_PERMISSION_REQUEST);
            return;
        }
        final LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
            Toast.makeText(this,"El GPS esta desactivado",Toast.LENGTH_LONG).show();
        }else{
            nLocationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000, 5, this);
        }
    }

    public void onClickStop(View view) {
        nLocationManager.removeUpdates(this);
    }

    @Override
    protected void onDestroy() {
        nLocationManager.removeUpdates(this);
        super.onDestroy();
    }

    @Override
    public void onLocationChanged(Location location) {
        LATI = "+"+String.valueOf(location.getLatitude());
        LATI = LATI.substring(0,9);
        LONG = String.valueOf(location.getLongitude());
        LONG = LONG.substring(0,9);
        tvLat.setText(LATI);
        tvLon.setText(LONG);
        java.util.Date dt = new java.util.Date();
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = sdf.format(dt);
        datetime.setText(currentTime);
        MSG = "<CEL1>"+LATI+LONG+"_"+currentTime;
        new UDP_Send().execute();
    }

    private class UDP_Send extends AsyncTask<Void,Void,Void>{
        private String ip="54.183.183.162";
        private Integer port=9222;
        @Override
        protected Void doInBackground(Void... params) {
            try {
                DatagramSocket udpSocket = new DatagramSocket(port);
                InetAddress serverAddr = InetAddress.getByName(ip);
                byte[] buf = (MSG).getBytes();
                DatagramPacket packet = new DatagramPacket(buf, buf.length,serverAddr, port);
                udpSocket.send(packet);
                udpSocket.close();
            } catch (SocketException e) {
                Log.e("Udp:", "Socket Error:", e);
            } catch (IOException e) {
                Log.e("Udp Send:", "IO Error:", e);
            }
            return null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case MY_PERMISSION_REQUEST: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    Toast.makeText(this,"Permisos autorizados",Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(this,"Permisos negados",Toast.LENGTH_LONG).show();
                }
                return;
            }
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }
}
